package models;

public class Comics extends Model {
    private String name;
    private String genre;
    private String price;

    public Comics()
    {

    }

    public Comics(String name, String genre, )
}